;



<?php $__env->startSection('content'); ?>

	<h3><?php echo e($msg->title); ?></h3>

	<h4>
		时间：<?php echo e($msg->updated_at); ?>

		&nbsp;&nbsp;
		作者：<?php echo e($msg->author); ?>


	</h4>

	<p>
		
		内容：<br />
		<?php echo e($msg->body); ?>


	</p>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('msg', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>