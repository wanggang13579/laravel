<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Laravel</title>
</head>
<body>
	
		<div id="header">
			<a href="/">首页</a>
			<hr />
		</div>

		<div id="content">
			


			<?php echo $__env->yieldContent('content'); ?>





		</div>

		<div id="footer">
			<hr />
			&copy;Laravel网页，我的一个小东西
		</div>

</body>
</html>