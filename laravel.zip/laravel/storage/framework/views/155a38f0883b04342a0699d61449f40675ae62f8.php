;

<?php $__env->startSection('content'); ?>
	
	<div>
		
		<form action="/laravel/public/edit/<?php echo e($msg->id); ?>" method="post">
			
			<?php /* //表单隐藏域....很有用，不能省掉 */ ?>
		<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"  />


			<p>
				标题：<input type="text" name="title" value="<?php echo e($msg->title); ?>" />

			</p>

			<p>
				作者：<input type="text" name="author" value="<?php echo e($msg->author); ?>" />

			</p>

			<p>
				内容：
				<br />
				<textarea name="body" id="" cols="30" rows="10">  <?php echo e($msg->body); ?>  </textarea>
			</p>

			<p>
				<input type="submit" value="提交" />

			</p>
		</form>




	</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('msg', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>