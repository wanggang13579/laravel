<?php $__env->startSection('content'); ?>

		<p>

		<a href="/laravel/public/add">添加新留言</a>
			<br />
		</p>
			<div>
				<table border="1"  cellpadding="0"  cellspacing="20">
					<tr>
						<th>id</th>
						<th>标题</th>
						<th>发表者</th>
						<th>发表时间</th>
						<th>可执行操作</th>
					</tr>
				
				<?php foreach($msgs as $msg): ?>
					<?php /* expr */ ?>
					<tr>
						<td><?php echo e($msg->id); ?></td>
						<td><?php echo e($msg->title); ?></td>
						<td><?php echo e($msg->author); ?></td>
						<td><?php echo e($msg->updated_at); ?></td>
						<td>
							<a href="/laravel/public/view/<?php echo e($msg->id); ?>">查看</a> |
							<a href="/laravel/public/delete/<?php echo e($msg->id); ?>">删除</a> |
							<a href="/laravel/public/edit/<?php echo e($msg->id); ?>">编辑</a>
						</td>
					</tr>





				<?php endforeach; ?>
				</table>
			</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('msg', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>